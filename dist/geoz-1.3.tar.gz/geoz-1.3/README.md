## Geographic Decision Zones (GeoZ)


GeoZ is a Python module integrating several machine learning algorithms to create Geographic Maps for the output of 
Unsupervised Machine Learning techniques. The module is geared mainly toward delineating the output from Clustering algorithms.

See (https://github.com/Ne-oL/geoz) for complete documentation (under construction).
